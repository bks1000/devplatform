根据数据库生成代码的工具
需要配置数据库连接
需要修改template中的模板即可。

完成myjava模板之后，再做一个创建表单的web功能，这就可以配套使用了。

系统整体结果是：用户在系统中创建数据库表(表信息元数据、物理表)，在系统中生成所有层代码，下载代码并添加到自己的项目中，稍作修改完成功能。
办公系统必要模块之一是工作流，尽量弄通一个开源工作流如 activity/jbpm


工作流参考：
https://www.activiti.org/    官网
https://www.activiti.org/quick-start
http://blog.csdn.net/xnf1991/article/details/52610277
http://www.cnblogs.com/WJ-163/p/6158698.html